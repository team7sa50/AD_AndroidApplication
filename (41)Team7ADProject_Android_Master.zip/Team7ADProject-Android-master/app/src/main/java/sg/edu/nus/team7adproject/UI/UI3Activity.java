package sg.edu.nus.team7adproject.UI;

import androidx.appcompat.app.AppCompatActivity;
import sg.edu.nus.team7adproject.R;

import android.os.Bundle;

public class UI3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ui3);
    }
}
